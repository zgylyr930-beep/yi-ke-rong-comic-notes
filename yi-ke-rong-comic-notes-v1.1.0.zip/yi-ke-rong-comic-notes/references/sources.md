# 来源与取舍

主体方法：小黑正文配图 skill 及其构图、风格、提示词参考；本次已重新读取相关文件。
- https://github.com/helloianneo/ian-xiaohei-illustrations/blob/main/ian-xiaohei-illustrations/SKILL.md
- https://github.com/helloianneo/ian-xiaohei-illustrations/blob/main/ian-xiaohei-illustrations/references/composition-patterns.md
- https://github.com/helloianneo/ian-xiaohei-illustrations/blob/main/ian-xiaohei-illustrations/references/style-dna.md
- https://github.com/helloianneo/ian-xiaohei-illustrations/blob/main/ian-xiaohei-illustrations/references/prompt-template.md

用户2026-11-14修订：一图尽量一个人物一句话，主体和文字更克制，禁止页脚类型名，比例严格按其参考。角色和黑白蓝配色使用用户四张图片。原小黑的角色和红橙色不继承；不搬用其旧图构图。小黄新增作为角色身份、媒介变量、提示词分工与返修流程的参考；不继承其角色、色彩和身体形变。旧 yi-ke-rong-ai-notes 不读取、不继承、不删除。

规则为针对用户需求重新编写，未打包他人角色资产或代码。

补充对照：https://github.com/ChenShuo2004/cs-skills/tree/main/cs-xiaohuang-skill 。详细差异见仓库 COMPARISON.md。
