# 与小黑、小黄技能的对照与本版补齐

核对日期：2026-11-14。依据双方SKILL.md及下列角色、构图与提示词参考文件。

| 维度 | 对方明确之处 | 一颗蓉原有缺口 | 本版处理 |
| --- | --- | --- | --- |
| 角色职责 | 小黑定义性格、工作职责及装饰判断；小黄定义品牌语义 | 外形详细，行动性格不够明确 | ip-variants：实践者、观察者、解释者；无用人物可省略 |
| 认知锚点 | 两者先找判断、转折、关系，避免平均配图 | 有逐页媒介选择，隐喻推导偏概括 | 补充动作—物件—结果方法及结构选择 |
| 身份与变量 | 小黄区分DNA、媒介、动作、风格迁移 | 未独立界定资产模式与媒介转换 | ip-variants，明确身份图和风格图职责 |
| 提示词 | 小黑有单图模板，小黄有标准图、迁移、修复模板 | 原模板侧重场景与结构 | prompt-templates新增整合、截图、IP与局部修复模板 |
| 返修标准 | 小黄区分局部与多锚点失败 | 有检查清单，重画阈值不具体 | iteration-rules加入阻断条件与返修分流 |
| 示例校准 | 小黑示例仅低频校准，禁止复刻旧构图 | 人物参考齐全，案例管理不明确 | 示例只校准密度和层级，不把案例内容写成默认模板 |
| 边界 | 两者以正文插图/品牌IP为主 | 一颗蓉还需整合新闻与整页文字 | 保留3:4笔记、截图与可选人物，不照搬每张必须有人及禁止结构图 |

本版仿照工作流、目录分工和约束粒度，未打包对方角色图、示例图或代码。不会为了相似而移除用户已经明确的截图、日式场景融合与右上页标规则。

来源：
- https://github.com/helloianneo/ian-xiaohei-illustrations/tree/main/ian-xiaohei-illustrations
- https://github.com/ChenShuo2004/cs-skills/tree/main/cs-xiaohuang-skill
- 小黑 references/composition-patterns.md、xiaohei-ip.md
- 小黄 references/character-dna.md、media-and-variants.md、ip-prompt-templates.md
