# 一颗蓉的AI日志 · 新版形象与笔记 Skill

稳定版 v1.1.0 · 2026-11-14

以一颗蓉原创 IP 为人物基础，按内容选择新闻截图、短正文、结构拆解图或场景漫画。不是每页都需要人物，也不是每套都需要漫画。

## 使用

将本仓库完整下载到 `~/.codex/skills/yi-ke-rong-comic-notes/`，保持 SKILL.md、references、assets 和 agents 的相对位置。重新加载技能后，直接请求：

> 使用 yi-ke-rong-comic-notes，制作 AI 日志 090 期。先分析我提供的原始截图，再决定哪些页用截图、结构图或漫画。

只需更新规则时请明确说“只更新 skill，不生成图片”。需要返修时指定页码和变化。

## 本版规则

- 白底、黑色文字与线条、#2A8CFF 蓝色强调；真实截图保留原色。
- 右上角统一 `AI日志090期-01` 格式，期数由用户指定。
- 不出现“01封面”等底部制作标签。
- 默认双眼自然睁开，人物比例按三视图，不机械眨单眼。
- 每页按信息选择媒介，人物可省略；人物与桌面、地面和场景有真实接触。
- 原始截图作为事实素材，优先直接嵌入，不让模型伪造新闻或界面。
- 保持文字、图像和留白的层级；成图需检查中文、人物、来源与页码。

## 文件

- [技能入口](SKILL.md)
- [人物与画风](references/character-and-style.md)
- [整合排版](references/integrated-layout.md)
- [截图使用](references/source-materials.md)
- [场景叙事](references/visual-storytelling.md)
- [交付检查](references/qa.md)
- [参考来源](references/sources.md)

![一颗蓉角色三视图](assets/character-turnaround.png)

## 来源与权利

方法参考小黑漫画配图技能，具体链接与取舍见 sources.md。角色参考图由一颗蓉提供；本仓库不含参考作者的角色资产。公开展示不代表授予一颗蓉 IP 的商用授权。

本次依据小黑与小黄进一步细化了角色职责、变量边界、任务模板及返修分流。见 [逐项对照](COMPARISON.md)。
